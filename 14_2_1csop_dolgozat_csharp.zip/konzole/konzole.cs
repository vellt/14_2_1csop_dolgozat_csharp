﻿using konzole.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace konzole
{
    class Program
    {
        static void Main(string[] args)
        {
            NetworkService backend = new NetworkService("http://localhost:3000/etelek");

            List<User> users = backend.GET();
            users.ForEach(x => Console.WriteLine($"{x.TizGrammAlatti()} {x.kategoria()}"));
        }
    }
}
