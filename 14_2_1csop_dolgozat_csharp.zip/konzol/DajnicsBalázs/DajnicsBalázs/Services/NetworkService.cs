﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;


namespace DajnicsBalázs.Services
{
    class NetworkService
    {
        string url;

        public NetworkService(string url)
        {
            this.url = url;
        }
        public List<User> GET()
    }
}
